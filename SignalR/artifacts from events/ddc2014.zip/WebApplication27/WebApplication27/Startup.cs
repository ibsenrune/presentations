﻿using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication27
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.MapSignalR();

            System.Threading.Tasks.Task.Factory.StartNew(() => BirdRunner.Run());
        }
    }
}