﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication27
{
    public class UghConnection : PersistentConnection
    {
        protected override System.Threading.Tasks.Task OnReceived(IRequest request, string connectionId, string data)
        {
            this.Connection.Broadcast(data, connectionId);
            return base.OnReceived(request, connectionId, data);
        }
    }
}