﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication27
{
    public class UghHub : Hub
    {
        public void UpdatePlayerInfo(UghPlayerInfo player)
        {
            this.Clients.Others.UpdatePlayerInfo(player);
        }
    }
}