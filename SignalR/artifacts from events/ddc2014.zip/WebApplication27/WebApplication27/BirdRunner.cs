﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;

namespace WebApplication27
{
    public class BirdRunner
    {
        public static void Run()
        {
            while (true)
            {
                Thread.Sleep(10000);
                FlyBy();
            }
        }

        private static void FlyBy()
        {
            for (int i = 0; i < 48; i++)
            {
                var b = new Bird
                {
                    X = -32 + 10 * i,
                    Y = 100,
                    CurrentFrame = i % 12
                };
                Thread.Sleep(100);
                SendBirdMessageToAllClients(b);
            }
        }

        private static void SendBirdMessageToAllClients(Bird b)
        {
            IHubContext ughHub = GlobalHost.ConnectionManager.GetHubContext<UghHub>();
            ughHub.Clients.All.UpdateBirdInfo(b);
        }
    }
}