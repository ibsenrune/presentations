﻿window.getParameterByName = function (name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
};

var ugh =
(function () {
    var viewport = { width: 352, height: 256 },
        scaleFactor = 2;
    var players = {};
    var player = null;
    var canvas = {};
    var pterodactylus = {
        visible: true,
        currentFrame: 0,
        x: -100,
        y:  viewport.height / 2
    },
        init = function (playerName, canvasId, spritesPath, splashPath) {
            canvas = document.getElementById(canvasId);
            
            var sprites = new Image();
            sprites.src = spritesPath;
            var splash = new Image();
            splash.src = splashPath;
            splash.onload = initialize;
            var bottomBar = { height: 16, width: 352 },
                playerWidth = 32,
                playerHeight = 25;
            player = {
                name: playerName || 'Rune',
                x: viewport.width / 2,
                y: viewport.height - bottomBar.height - playerHeight,
                currentFrame: 0
            };
            players[player.name] = player;
            var draw = canvas.getContext("2d"),
                timerId,
                maxFrame = 6,
                playerGraphicsXOffset = 322,
                playerGraphicsYOffset = 531,

                pterodactylusDimensions = {
                    spriteLeftOffset: 321,
                    spriteTopOffset: 201,
                    height: 23,
                    width: 32                
                },
                xVel = 0,
                yVel = 0,

                xAcc = 0,
                yAcc = 0,

                bounceFriction = 0.5,
                airFriction = 0.98,

                playerHorizontalTurnAcc = 0.2,
                playerPropelAcc = 0.35,
                playerPropelBackwardsAcc = 0.20,

                gravity = 0.2,

                propelTurningDirection = 0;

            function onKeyDown(e) {
                if (e.keyCode == 39) // Right
                    xAcc = playerHorizontalTurnAcc;
                if (e.keyCode == 37) // Left
                    xAcc = -playerHorizontalTurnAcc;
                if (e.keyCode == 38) // Up
                {
                    propelTurningDirection = 1;
                    yAcc = -playerPropelAcc;
                }
                if (e.keyCode == 40) // Down
                {
                    propelTurningDirection = -1;
                    yAcc = playerPropelBackwardsAcc;
                }
            }

            function onKeyUp(e) {
                if (e.keyCode == 39) // Right
                    xAcc = 0;
                if (e.keyCode == 37) // Left
                    xAcc = 0;
                if (e.keyCode == 38) // Up
                {
                    propelTurningDirection = 0;
                    yAcc = 0;
                }
                if (e.keyCode == 40) // Down
                {
                    propelTurningDirection = 0;
                    yAcc = 0;
                }
            };

            function drawImage(img, sx, sy, swidth, sheight, x, y, width, height) {
                draw.drawImage(img, sx, sy, swidth, sheight, scaleFactor * x, scaleFactor * y, scaleFactor * width, scaleFactor * height);
            }

            function clearRect(x, y, width, height) {
                draw.clearRect(scaleFactor * x, scaleFactor * y, scaleFactor * width, scaleFactor * height);
            }

            function drawSplash() {
                drawImage(splash, 0, 0, splash.width, splash.height, 0, 0, viewport.width, viewport.height);
            }

            function drawBottomBar() {
                clearRect(0, viewport.height - bottomBar.height, bottomBar.width, bottomBar.height);
                drawImage(sprites, 321, 0, bottomBar.width, bottomBar.height, 0, viewport.height - bottomBar.height, bottomBar.width, bottomBar.height);
            };
            function drawPlayer(p) {
                drawImage(sprites, playerGraphicsXOffset + p.currentFrame * playerWidth, playerGraphicsYOffset, playerWidth, playerHeight, p.x, p.y, playerWidth, playerHeight);
            };

            function drawPterodactylus(p) {
                var horizontalSpriteOffset = pterodactylusDimensions.spriteLeftOffset + (p.currentFrame < 8 ? (p.currentFrame+2) * pterodactylusDimensions.width : (p.currentFrame-8) * pterodactylusDimensions.width);
                var verticalSpriteOffset   = pterodactylusDimensions.spriteTopOffset  + (p.currentFrame < 8 ? 0 : 1 * pterodactylusDimensions.height);

                drawImage(sprites, horizontalSpriteOffset, verticalSpriteOffset, pterodactylusDimensions.width, pterodactylusDimensions.height, p.x, p.y, pterodactylusDimensions.width, pterodactylusDimensions.height);
            }

            function initialize() {
                drawSplash();
            
                window.onkeydown = function (e) {
                    if (e.keyCode === 32) { //Spacebar
                        startGame();
                    }
                }
            }

            function startGame() {
                window.onkeydown = onKeyDown;
                window.onkeyup = onKeyUp;
                drawBottomBar();
                timerId = window.setInterval(gameLoop, 33);
            }

            function gameLoop() {
                clearRect(0, 0, viewport.width, viewport.height - bottomBar.height);

                for (var name in players) {
                    drawPlayer(players[name]);
                }

                if (pterodactylus !== null && pterodactylus.visible) {
                    drawPterodactylus(pterodactylus);
                }

                player.currentFrame = (player.currentFrame + maxFrame + propelTurningDirection) % maxFrame;

                xVel += xAcc;
                yVel += yAcc + gravity;

                player.x += xVel;
                player.y += yVel;

                physics();
            }

            function physics() {
                if (player.y + playerHeight > viewport.height - bottomBar.height) {
                    player.y = viewport.height - playerHeight - bottomBar.height;

                    yVel = -yVel * bounceFriction;
                    xVel *= bounceFriction;
                }

                if (player.y < 0) {
                    player.y = 0;
                    yVel = -yVel * bounceFriction;
                }

                if (player.x + playerWidth > viewport.width) {
                    player.x = viewport.width - playerWidth;

                    xVel = -xVel * bounceFriction;
                    yVel *= bounceFriction;
                }

                if (player.x < 0) {
                    player.x = 0;

                    xVel = -xVel * bounceFriction;
                    yVel *= bounceFriction;
                }

                xVel *= airFriction;
                yVel *= airFriction;
            }
    };

    updatePlayer = function (player) {
        players[player.name] = player;
    },
    updatePterodactylus = function (pos) {
        pterodactylus = {
            currentFrame: pos.currentFrame,
            x: pos.x,
            y: pos.y,
            visible : true,
        };
    },
    getCurrentPosition = function () {
        return player;
    };

    return {
        init: init,
        updatePlayerInfo: updatePlayer,
        updateBirdInfo: updatePterodactylus,
        getCurrentPlayerInfo : getCurrentPosition
    };
})();